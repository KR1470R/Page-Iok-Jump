from PIL import ImageTk, Image 
from tkinter import *
import os
import signal
import sys
from pygame import mixer
from game import main
from threading import Thread
my_coin = open("My_Coin.txt", "r")
coins = my_coin.read()
my_coin.close()
PATH_TO_MUSIC = os.path.abspath('media/music/background_msc.mp3')

def settings_icon():
    global settings
    if w == 1920 and h == 1080:
        path_to_settings = os.path.abspath('media/screen_resolution/1920_1080/main_menu/settings.png')
        settings_icon = PhotoImage(file=path_to_settings)
        settings = Label(image=settings_icon,bg='#3B4EA3',cursor='hand1')
        settings.image = settings_icon
        settings.place(relx=1,rely=0.0,anchor=NE)
        settings.bind('<Button-1>',open_settings)
    
    elif w == 1366 or 1360 and h == 768:
        path_to_settings = os.path.abspath('media/screen_resolution/1366_768/main_menu/settings.png')
        settings_icon = PhotoImage(file=path_to_settings)
        settings = Label(image=settings_icon,bg='#3B4EA3',cursor='hand1')
        settings.image = settings_icon
        settings.place(relx=1,rely=0.0,anchor=NE)
        settings.bind('<Button-1>',open_settings)

def volume_icon():
    path_to_off = os.path.abspath('media/settings/volume_off.png')
    volume_off_1 = PhotoImage(file=path_to_off)
    def play_music():
        mixer.init()
        mixer.music.load(PATH_TO_MUSIC)
        mixer.music.play(-1, 0.0)
    def stop_music():
        mixer.music.stop()
    def volume_off(event):
        stop_music()
        volume_galka.config(image=volume_off_1)
        volume_galka.bind('<Button-1>',volume_on_1)
    def volume_on_1(event):
        volume_galka.config(image=volume_icon_1)
        volume_galka.bind('<Button-1>',volume_off)
        play_music()
    w = root.winfo_screenwidth()
    h = root.winfo_screenheight()
    if w == 1920 and h == 1080: 
        path_volume = os.path.abspath('media/settings/volume_on.png')
        volume_icon_1 = PhotoImage(file=path_volume)
        volume_galka = Label(image=volume_icon_1,bg='#3B4EA3',cursor='hand1')
        volume_galka.bind('<Button-1>',volume_off)
        volume_galka.image = volume_icon_1
        volume_galka.place(x=1800)
        
    elif w == 1360 and h == 768:
        path_volume = os.path.abspath('media/settings/volume_on.png')
        volume_icon_1 = PhotoImage(file=path_volume)
        volume_galka = Label(image=volume_icon_1,bg='#3B4EA3',cursor='hand1')
        volume_galka.bind('<Button-1>',volume_off)
        volume_galka.image = volume_icon_1
        volume_galka.place(x=1250)
    play_music()
def play_with_game():
    music = Thread(target=volume_icon)
    music.start()
    game = Thread(target=main)
    game.start()

def play_music_with_game(event):
    game = Thread(target=main)
    game.start()
    music = Thread(target=play_music)
    music.start()
def window():
    global root
    global w, h
    global label
    global button 
    global button_exit
    global settings


    root = Tk()
    root.resizable(False, False)


    w = root.winfo_screenwidth()
    h = root.winfo_screenheight()

    print(coins, "\n")
    
    if w == 1920 and h == 1080:
        path_to_coin = os.path.abspath('media/screen_resolution/1920_1080/main_menu/coin.png')
        coin_icon = PhotoImage(file = path_to_coin)
        coin_icon_spawn = Label(image=coin_icon,bg='#3B4EA3')
        coin_icon_spawn.grid(row=0,column=0)

        coins_label = Label(text =coins, fg = "#E6B71C",
          bg = "#3B4EA3",font = ("Inpact", 39,'bold'))
        coins_label.grid(row=0,column=1)
        print(w,h)
        root.geometry("{}x{}".format(w,h))
        root.title('Iok Jump')
        
        path_to_welcome = os.path.abspath('media/screen_resolution/1920_1080/main_menu/welcome.png')
        welcome = PhotoImage(file=path_to_welcome)
        label = Label(root, image=welcome,bg='#3B4EA3')
        label.place(relx=0.5,rely=0.2, anchor=CENTER)

        path_to_icon_start_button = os.path.abspath('media/screen_resolution/1920_1080/main_menu/start_button.png')
        icon_start_button = PhotoImage(file=path_to_icon_start_button)
        button = Label(root,image=icon_start_button,cursor='hand1',width=315,height=140,bg='#3B4EA3')
        button.bind('<Button-1>',main)
        button.place(relx=0.5,rely=0.4,anchor=CENTER)

        path_to_icon_exit_button = os.path.abspath('media/screen_resolution/1920_1080/main_menu/exit_button.png')
        icon_exit_button = PhotoImage(file=path_to_icon_exit_button)
        button_exit = Label(root,image=icon_exit_button,cursor='hand1',width=315,height=140,bg='#3B4EA3')
        button_exit.bind('<Button-1>',exit)
        button_exit.place(relx=0.5,rely=0.6,anchor=CENTER)

        volume_icon()

        root.config(bg='#3B4EA3')

        path_character = os.path.abspath('media/screen_resolution/1920_1080/main_menu/ball.png')
        character = PhotoImage(file=path_character)
        for_menu = Label(image=character,bg='#3B4EA3')
        for_menu.grid(row=5,column=2)

        root.bind('<Return>',main)
        root.mainloop()

    elif w == 1366 or 1360 and h == 768:
        print(w,h)
        root.geometry("{}x{}".format(w,h))
        root.title('Iok Jump')
        
        path_to_coin = os.path.abspath('media/screen_resolution/1366_768/main_menu/coin.png')
        coin_icon = PhotoImage(file = path_to_coin)
        coin_icon_spawn = Label(image=coin_icon,bg='#3B4EA3')
        coin_icon_spawn.grid(row=0,column=0)

        coins_label = Label(text =coins, fg = "#E6B71C",
          bg = "#3B4EA3",font = ("Inpact", 25,'bold'))
        coins_label.grid(row=0,column=2)

        path_character = os.path.abspath('media/screen_resolution/1366_768/main_menu/ball.png')
        character = PhotoImage(file=path_character)
        for_menu = Label(image=character,bg='#3B4EA3')
        for_menu.grid(row=6,column=3)

        path_to_welcome = os.path.abspath('media/screen_resolution/1366_768/main_menu/welcome.png')
        welcome = PhotoImage(file=path_to_welcome)
        label = Label(root, image=welcome,bg='#3B4EA3')
        label.place(relx=0.5,rely=0.2, anchor=CENTER)

        path_to_icon_start_button = os.path.abspath('media/screen_resolution/1366_768/main_menu/start_button.png')
        icon_start_button = PhotoImage(file=path_to_icon_start_button)
        button = Label(root,image=icon_start_button,cursor='hand1',width=315,height=140,bg='#3B4EA3')
        button.bind('<Button-1>',main)
        button.place(relx=0.5,rely=0.4,anchor=CENTER)

        volume_icon()

        path_to_icon_exit_button = os.path.abspath('media/screen_resolution/1366_768/main_menu/exit_button.png')
        icon_exit_button = PhotoImage(file=path_to_icon_exit_button)
        button_exit = Label(root,image=icon_exit_button,cursor='hand1',width=315,height=140,bg='#3B4EA3')
        button_exit.bind('<Button-1>',exit)
        button_exit.place(relx=0.5,rely=0.6,anchor=CENTER)

        root.config(bg='#3B4EA3')

        root.bind('<Return>',main)
        root.mainloop()

window()

def exit():

    os.kill(os.getpid(),signal.SIGKILL())